<?php
/* Konfigurasi DB 
Available server :
- mysql
- sqlsrv (for windows)
- mssql (for linux)
*/

$dbConfig[0]['host'] = 'localhost';
$dbConfig[0]['user'] = 'root';
$dbConfig[0]['pass'] = 'root123root';
$dbConfig[0]['name'] = 'cat_polda';
$dbConfig[0]['server'] = 'mysql';
$dbConfig[0]['prefix'] = 'cat';
$dbConfig[0]['preftable'] = 'ck';

// $dbConfig[0]['host'] = 'ANDREASS-PC\SQLEXPRESS';
// $dbConfig[0]['user'] = 'sa';
// $dbConfig[0]['pass'] = 'root123root';
// $dbConfig[0]['name'] = 'db_sipmas';
// $dbConfig[0]['server'] = 'sqlsrv';

?>
